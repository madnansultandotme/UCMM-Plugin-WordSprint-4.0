=== UCMM Wordsprint Plugin ===
Contributors: Your Name
Tags: Maintenance Mode, Coming Soon, Under Construction
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0
Requires PHP: 8.3
License: GPLv2 or later

== Description ==
UCMM Wordsprint Plugin allows you to apply Maintenance Mode, Coming Soon, or Under Construction functionality to your WordPress site with the following features:
- Maintenance mode on specific pages or posts.
- Whitelist users to view the website.
- Add social icons and footer text on the maintenance page.
